/** Automatically generated file. DO NOT MODIFY */
package com.mediaphile_bit272.mediaphilev2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}